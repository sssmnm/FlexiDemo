import React from 'react';
import './App.css';
import FlexiComponentContainer from './components/FlexiComponent/FlexiComponentContainer';

function App() {
  return (
    <div className="App">
        <FlexiComponentContainer />
    </div>
  );
}

export default App;
