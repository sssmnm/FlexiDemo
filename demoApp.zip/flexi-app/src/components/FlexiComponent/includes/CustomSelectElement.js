import React, {Fragment } from 'react';
import PropTypes from 'prop-types';
import OptionsComponent from './OptionsComponent';

const CustomSelectElement = ({entity, handleChange}) => (
  <Fragment>
    <label>
      {entity.label}
      <select key={entity.name} name={entity.name} value={entity.value} onChange={handleChange}>
        <OptionsComponent 
          key={entity.value} 
          options={entity.values} 
        />
      </select>
    </label>
  </Fragment>
);

CustomSelectElement.prototype={
    entity: PropTypes.object,
    handleChange: PropTypes.func,
};
CustomSelectElement.defaultProps = {
    entity: {}
  };
export default CustomSelectElement;