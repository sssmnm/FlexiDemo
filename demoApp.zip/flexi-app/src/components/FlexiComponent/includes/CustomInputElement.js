import React, {Fragment} from 'react';
import PropTypes from 'prop-types';

const CustomInputElement = ({entity, handleChange}) => (
  <Fragment>
    <label>{entity.label}</label>
    <input
      name={entity.name}
      type="text"
      placeholder={entity.label}
      onChange={handleChange}
    />
  </Fragment>
);

CustomInputElement.prototype = {
  entity: PropTypes.object,
  handleChange: PropTypes.func,
};
CustomInputElement.defaultProps = {
  entity: {},
};
export default CustomInputElement;
